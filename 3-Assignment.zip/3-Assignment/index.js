document.addEventListener('DOMContentLoaded', () => {
    loadTasks();
    document.getElementById('task-form').addEventListener('submit', addTask);
    document.getElementById('search-bar').addEventListener('keyup', searchTasks);
});

function loadTasks() {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    const taskList = document.getElementById('task-list');
    taskList.innerHTML = '';

    tasks.forEach(task => {
        createTaskElement(task);
    });
}

function saveTasks(tasks) {
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function addTask(event) {
    event.preventDefault();

    const title = document.getElementById('task-title').value;
    const description = document.getElementById('task-description').value;
    const dueDate = document.getElementById('task-due-date').value;

    if (title === '' || dueDate === '') return;

    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    const newTask = {
        id: Date.now(),
        title,
        description,
        dueDate,
        completed: false
    };

    tasks.push(newTask);
    saveTasks(tasks);

    createTaskElement(newTask);

    document.getElementById('task-form').reset();
}

function createTaskElement(task) {
    const taskList = document.getElementById('task-list');
    const li = document.createElement('li');
    li.dataset.id = task.id;
    li.innerHTML = `
        <strong>${task.title}</strong>
        <p>${task.description}</p>
        <small>Due Date: ${task.dueDate}</small>
        <button class="edit-btn" onclick="editTask(${task.id})">Edit</button>
        <button class="delete-btn" onclick="deleteTask(${task.id})">Delete</button>
        <input type="checkbox" ${task.completed ? 'checked' : ''} onchange="toggleCompletion(${task.id})"> Completed
    `;
    if (task.completed) {
        li.classList.add('completed');
    }
    taskList.appendChild(li);
}

function editTask(taskId) {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    const task = tasks.find(t => t.id === taskId);

    if (!task) return;

    document.getElementById('task-title').value = task.title;
    document.getElementById('task-description').value = task.description;
    document.getElementById('task-due-date').value = task.dueDate;

    deleteTask(taskId);
}

function deleteTask(taskId) {
    if (!confirm('Are you sure you want to delete this task?')) return;

    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks = tasks.filter(task => task.id !== taskId);
    saveTasks(tasks);

    document.querySelector(`li[data-id='${taskId}']`).remove();
}

function toggleCompletion(taskId) {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    const task = tasks.find(t => t.id === taskId);

    if (!task) return;

    task.completed = !task.completed;
    saveTasks(tasks);

    document.querySelector(`li[data-id='${taskId}']`).classList.toggle('completed');
}

function filterTasks(status) {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    const taskList = document.getElementById('task-list');
    taskList.innerHTML = '';

    tasks
        .filter(task => {
            if (status === 'all') return true;
            if (status === 'completed') return task.completed;
            if (status === 'incomplete') return !task.completed;
        })
        .forEach(task => createTaskElement(task));
}

function searchTasks() {
    const query = document.getElementById('search-bar').value.toLowerCase();
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    const taskList = document.getElementById('task-list');
    taskList.innerHTML = '';

    tasks
        .filter(task => task.title.toLowerCase().includes(query) || task.description.toLowerCase().includes(query))
        .forEach(task => createTaskElement(task));
}
